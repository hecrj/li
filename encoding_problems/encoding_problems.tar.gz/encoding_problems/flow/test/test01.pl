% esta entrada corresponde al primer ejemplo en el enunciado
size(9).
%  color   init  fin
c(blue,    1,1,  9,9).
