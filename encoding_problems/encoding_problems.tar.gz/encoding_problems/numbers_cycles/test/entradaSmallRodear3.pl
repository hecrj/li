rows(3).
columns(5).
num(1,2,2).
num(1,3,1).
num(2,3,1).
num(3,1,0).
num(3,5,2).
