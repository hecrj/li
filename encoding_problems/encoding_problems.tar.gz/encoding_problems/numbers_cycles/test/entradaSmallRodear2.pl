rows(3).
columns(4).
num(1,3,1).
num(1,4,3).
num(2,1,0).
num(2,3,2).
num(3,4,3).
