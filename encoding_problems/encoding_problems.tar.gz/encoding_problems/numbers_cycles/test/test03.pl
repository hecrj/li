rows(9).
columns(9).

num(1, 2, 1).
num(2, 1, 1).
num(2, 2, 2).
num(2, 3, 1).
num(3, 2, 1).

num(1, 4, 1).
num(2, 4, 2).
num(2, 5, 1).
num(3, 4, 1).

num(1, 3, 1).
num(3, 3, 1).

num(7, 8, 0).
num(8, 8, 3).
num(9, 7, 3).
num(9, 8, 3).
num(9, 9, 2).