rows(9).
columns(9).

num(_, _, _):- fail.