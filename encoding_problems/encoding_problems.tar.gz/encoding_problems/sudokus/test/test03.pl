filled(1, 1, 1).
filled(9, 1, 1).
