There are two directories:
  - thorsat:
        Contains my SAT solver.
  - encoding_problems:
        Contains the directories:
            1. sudokus: This problem was previously delivered.
            2. numbers_cycles: This is the problem that has been assigned to me.
            3. flow: I did this problem because I found it interesting!

        And the files:
            1. cardinalityConstraints.pl: Cardinality constraints that are used by all the solvers.
            2. writeClauses.pl: Common code to write clauses and run the SAT solvers.

Use the Makefile inside the directory of every problem to compile the solvers.
It is necessary to have swipl installed. By default, the solvers use picosat to solve the problems.
It is possible to use my SAT solver changing the predicate:
    useMySolver(0).
To:
    useMySolver(1).

Then, the solvers would compile my SAT solver (if needed) and use it to solve the problems.
For this to work, the directory structure must remain untouched.

Héctor Ramón Jiménez

