Se incluye el archivo:
    solver.pl: Contiene la estructura básica que comparten los problemas (cubos, misioneros y puentes).
               Es lo suficientemente flexible como para adaptarse a las características del problema.

Además, se incluyen los siguientes directorios:
    doc: Contiene un documento PDF con la descripción de los problemas a resolver.
    cubos, misioneros, puente y charlas: Resuelven los problemas descritos en el PDF anterior.

Se adjunta un Makefile dentro de los directorios de los problemas para compilar fácilmente.
Sea X el nombre del directorio del problema, el ejecutable generado tiene nombre X.out
Es necesario tener instalado swipl para compilar y ejecutar los solucionadores.

Héctor Ramón Jiménez

